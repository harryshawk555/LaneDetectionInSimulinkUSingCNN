function yWorld = computeBoundaryModel(model, xWorld)

% Copyright 2020-2021 The MathWorks, Inc.
yWorld = polyval(model, xWorld);

end